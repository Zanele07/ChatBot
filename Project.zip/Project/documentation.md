# News Agency

## Overview
This project aims to create a chatbot for Olympic news. The main goal is to provide real-time updates, player statistics, and predictions.

## Scope
The project includes features like:
- Olympic news feed
- Prediction model for future winners
- Countries gaining momentum

The project does not cover xxx.

## Audience
This documentation is intended for developers, project managers, and users who want to extend or use the project.

## Installation



### Running the Application*
To start the application, use the following command:
```bash
streamlit run app.py

#