import streamlit as st
import boto3
import requests
import pandas as pd
import pydeck as pdk
from PIL import Image
import altair as alt
import numpy as np
from langchain.tools import tool
from langchain_aws import ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

human_avatar = "https://cdn-icons-png.flaticon.com/128/1248/1248343.png"
chatbot_avatar = "https://cdn-icons-png.flaticon.com/128/140/140398.png"

st.title("Alpha News")

athletes_df = pd.read_csv("athlete_events.csv")

# Sidebar for city selection
city = st.sidebar.selectbox("Select a City", athletes_df["City"].unique())

# Filter data based on selected city
filtered_venues_df = athletes_df[athletes_df["City"] == city]

# Display news details
st.header(f"Olympics News from {city}")

prompt = ChatPromptTemplate.from_messages(
    [("system", """You are a helpful assistant that helps users retrive data about the past summer Olympics games.
        You use visual representation to present charts and diagrams.
        Give summarized and clear responses. Do not include datasources.
        First try to use querying tools and if that fails use knowledgebase tool.
        If you need to predict number of medals use 'predictMedals' tool. Using this tool you will get total number of medals and athletes.
      """),
     ("placeholder", "{history}"), 
     ("human", "{input}"),
     ("placeholder", "{agent_scratchpad}")],
)


@tool
def knowledgebase():
       """If other provided tools do not return good value use this tool to search 
            wikipedia to get all the info for specific prompt
       """
       api_wrapper = WikipediaAPIWrapper(top_k_results=5, doc_content_chars_max=100)
       wikipedia = WikipediaQueryRun(api_wrapper=api_wrapper)
       return wikipedia

@tool
def historicalWeatherAPI(lon: str, lat: str, start: str, end: str):
    """Use this to find historical weather data based on the date of each event in the olympics.
        Find the city longitude and latitude and find the exact date for that event.
    """
    response = requests.get("https://archive-api.open-meteo.com/v1/archive", params={
        "latitude": lat,
        "longitude": lon,
        "start_date": start,
        "end_date": end
    })

    return response

@tool
def olympicsNewsAPI(query: str, language: str = "en", sortBy: str = "publishedAt"):
    """Use this to find articles related to the Olympics based on the sports.
       Find the article and find the published date for that article.
    """
    response = requests.get("https://newsapi.org/v2/everything", params={
        "q": query,             # Search query, e.g., 'Olympics'
        "language": language,    # Language filter, defaults to English
        "sortBy": sortBy,        # Sorting, defaults to latest articles
        "apiKey": "c8bc6d70a46a4e5698124a048ae67e0e"  # Your NewsAPI key
    })

    # Return the response in JSON format
    return response
    

tools = [ knowledgebase, historicalWeatherAPI, olympicsNewsAPI]#, predictMedals]
model_id = "anthropic.claude-3-haiku-20240307-v1:0"
agent = create_tool_calling_agent(ChatBedrock(model_id=model_id), tools, prompt)
chain = AgentExecutor(agent=agent, tools=tools, verbose=True)

memory = StreamlitChatMessageHistory(key="history")

chain_with_history = RunnableWithMessageHistory(
    chain, lambda _: memory, input_messages_key="input", history_messages_key="history"
)

for message in memory.messages:
    if message.type == "human":
        st.chat_message(message.type, avatar=human_avatar).write(message.content)
    else:
        st.chat_message(message.type, avatar=chatbot_avatar).write(message.content)

if user_input := st.sidebar.chat_input():
    config = {"configurable": {"session_id": "default"}}

    st.sidebar.chat_message("human", avatar=human_avatar).write(user_input)
    response = chain_with_history.invoke({"input": user_input}, config=config)
    st.sidebar.chat_message("ai", avatar=chatbot_avatar).write(response["output"])

if st.sidebar.button("Clear History"):
    memory.clear()