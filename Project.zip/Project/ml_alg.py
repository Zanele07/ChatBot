import pandas as pd
import sklearn as sk
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import Lasso


# #### data cleaning for past olympics results
# medal_mapping = {
#         'No medal': 0,
#         'Gold': 1,
#         'Silver': 2,
#         'Bronze': 3
# }

# data = pd.read_csv('olympics_dataset.csv')
# data['Medal'] = data['Medal'].map(medal_mapping)

# data = data[data['Year'] > 1959]
# data_only_medals = data[data['Medal'] > 0]

# medal_count = data_only_medals.groupby(['Team', 'Year', 'Event', 'Medal']).size().reset_index(name='Medal_Count')
# athlete_count = data.groupby(['Team', 'Year'])['Name'].nunique().reset_index(name='Num_Athletes')

# result = pd.merge(athlete_count, medal_count, on=['Team', 'Year'], how='left')
# result['Medal_Count'] = result['Medal_Count'].fillna(0)

# results_final = result.groupby(['Team', 'Year', 'Num_Athletes']).apply(lambda x: (x['Medal_Count'] > 0).sum()).reset_index(name='Total_Medals')
# results_final = results_final.sort_values(by=['Team', 'Year'])
# results_final.to_csv('team_year_total.csv', index=False)

# #### merging with gdp data

# data_gdp = pd.read_csv('gdp_1960_2020.csv')
# results_gdp = pd.merge(results_final, data_gdp, left_on=['Team', 'Year'], right_on=['country', 'year'], how='inner')
# results_gdp = results_gdp[['Team', 'Year', 'state', 'Num_Athletes', 'Total_Medals', 'gdp']]
# results_gdp.to_csv('team_year_gdp.csv', index=False)

# #### merging with population data

# data_population = pd.read_csv('team_population.csv')

# # merging with population
# all_data = pd.merge(results_gdp, data_population, left_on=['Team', 'Year'], right_on=['Country Name', 'Year'], how='inner')
# all_data.rename(columns={'gdp': 'Gdp'}, inplace=True)
# all_data = all_data[['Team','Year','state','Num_Athletes','Total_Medals','Gdp','Population']]
# all_data.to_csv('all_data.csv', index=False)

all_data = pd.read_csv('all_data.csv')

# #### predictions for 2024

# features = ['Num_Athletes', 'Gdp', 'Population']
# target = 'Total_Medals'

# X = all_data[features]
# y = all_data[target]

# scaler = StandardScaler()
# X_train, X_test, y_train, y_test, index_train, index_test = train_test_split(
#     X, y, all_data[['Team', 'Year']], test_size=0.2, random_state=42)

# X_train_scaled = scaler.fit_transform(X_train)
# X_test_scaled = scaler.transform(X_test)

# #knn

# model = KNeighborsRegressor(n_neighbors=10)  
# model.fit(X_train_scaled, y_train)

# y_pred_knn = model.predict(X_test_scaled)
# y_pred_df = pd.DataFrame({
#     'Team': index_test['Team'],
#     'Year': index_test['Year'],
#     'Predicted_Total_Medals': y_pred_knn
# })

# y_pred_df.to_csv('predicted_knn.csv', index=False)

# mse_knn = mean_squared_error(y_test, y_pred_knn)
# r2_knn = r2_score(y_test, y_pred_knn)

# print(f"Mean Squared Error knn: {mse_knn}")
# print(f"R^2 Score knn: {r2_knn}")

# # linear regression

# model = LinearRegression()
# model.fit(X_train_scaled, y_train)

# y_pred_lr = model.predict(X_test_scaled)

# mse_lr = mean_squared_error(y_test, y_pred_lr)
# r2_lr = r2_score(y_test, y_pred_lr)

# print(f"Mean Squared Error lr: {mse_lr}")
# print(f"R^2 Score lr: {r2_lr}")

# # random forest regression

# model = RandomForestRegressor(n_estimators=100, random_state=42)
# model.fit(X_train_scaled, y_train)

# y_pred_rf = model.predict(X_test_scaled)
# y_pred_df = pd.DataFrame({
#     'Team': index_test['Team'],
#     'Year': index_test['Year'],
#     'Predicted_Total_Medals': y_pred_rf
# })

# y_pred_df.to_csv('predicted_rf.csv', index=False)

# mse_rf = mean_squared_error(y_test, y_pred_rf)
# r2_rf = r2_score(y_test, y_pred_rf)

# print(f"Mean Squared Error rf: {mse_rf}")
# print(f"R^2 Score rf: {r2_rf}")

#### predict future 

def train_model_for_medals(data):
    features = ['Num_Athletes', 'Gdp', 'Population']
    target = 'Total_Medals'
    
    X = data[features]
    y = data[target]
    
    scaler = StandardScaler()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train_scaled = scaler.fit_transform(X_train)

    model = KNeighborsRegressor(n_neighbors=5)
    model.fit(X_train_scaled, y_train)

    return model, scaler

# Function to predict future GDP, Population, Num_Athletes based on Country and Year and then predict Total Medals
def predict_future_medals(country, year):

    country_data = all_data[all_data['Team'] == country]
    features = ['Year']
    gdp_population_targets = ['Gdp', 'Population']
    athlete_target = ['Num_Athletes']

    # Step 1: Predict GDP and Population
    X_gdp_pop = country_data[features]
    y_gdp_pop = country_data[gdp_population_targets]
    
    gdp_pop_model = LinearRegression()
    gdp_pop_model.fit(X_gdp_pop, y_gdp_pop)
    
    future_year = pd.DataFrame({'Year': [year]})
    predicted_gdp_pop = gdp_pop_model.predict(future_year)
    predicted_gdp = predicted_gdp_pop[0][0]
    predicted_population = predicted_gdp_pop[0][1]
    
    # Step 2: Predict Number of Athletes
    X_athletes = country_data[features]
    y_athletes = country_data[athlete_target]
    
    athlete_model = LinearRegression()
    athlete_model.fit(X_athletes, y_athletes)
    
    predicted_num_athletes = athlete_model.predict(future_year)[0][0]
    
    # Step 3: Predict Total Medals using KNN model
    medal_model, scaler = train_model_for_medals(all_data)
    
    # Prepare future data with the predicted values
    future_data = pd.DataFrame({
        'Num_Athletes': [predicted_num_athletes],
        'Gdp': [predicted_gdp],
        'Population': [predicted_population]
    })
    
    future_data_scaled = scaler.transform(future_data)
    
    # Predict total medals
    predicted_medals = medal_model.predict(future_data_scaled)[0]
    
    return predicted_medals, predicted_num_athletes

#### testing 
# country = 'South Africa'
# year = 2024
# predicted_medals, predicted_athletes = predict_future_medals(country, year)

# print(f"Predicted medals for {country} in {year}: {predicted_medals}")
# print(f"Predicted number of athletes: {predicted_athletes}")