######################################################################################
# This file is a skeleton code for the Chatbot to test tools before being deployed to the final product.
######################################################################################
import streamlit as st
import boto3
import requests
import pandas as pd
import pydeck as pdk
from PIL import Image
import altair as alt
import numpy as np
from langchain.tools import tool
from langchain_aws import ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper
#from ml_alg import train_model_for_medals, predict_future_medals
import instaloader

######################################################################################
# # Mock Prediction Function
# def mock_predict_medals(country: str, year: int):
#     """Mock function to simulate medal predictions."""
#     np.random.seed(0)  # For reproducibility
#     total_medals = np.random.randint(0, 20)  # Random number of total medals
#     total_athletes = np.random.randint(0, 100)  # Random number of total athletes
#     return {"medals": total_medals, "athletes": total_athletes}

######################################################################################
# Set up page configuration
st.set_page_config(page_title="Alpha News", page_icon=":medal:", layout="wide")
dynamodb = boto3.resource('dynamodb')
human_avatar = "https://cdn-icons-png.flaticon.com/128/1248/1248343.png"
chatbot_avatar = "https://cdn-icons-png.flaticon.com/128/140/140398.png"

st.title("Alpha News")
df1 = pd.read_csv("team_year.csv")
print(df1)
df1 = df1.rename(columns={"Latitude": "latitude", "Longitude": "longitude"})

# Sidebar for navigation
# st.sidebar.header("Navigation")
# page = st.sidebar.selectbox("Select", ["Olympic News", "Medal Prediction"])

# Filter data based on selected city for the Olympics News page

city = st.sidebar.selectbox("Select a City", df["City"].unique())
filtered_df = df[df["City"] == city]
st.header(f"Olympics News from {city}")

######################################################################################
# Displaying Visualisation

# Display map of event locations
st.header("Event Locations")
map_data = filtered_df[["latitude", "longitude"]]
st.map(map_data)

# Pydeck map for better visualization
st.subheader("Map Visualization")
deck = pdk.Deck(
    initial_view_state=pdk.ViewState(
        latitude=filtered_df["latitude"].mean(),
        longitude=filtered_df["longitude"].mean(),
        zoom=12,
        pitch=0
    ),
    layers=[
        pdk.Layer(
            "ScatterplotLayer",
            data=filtered_df,
            get_position=["longitude", "latitude"],
            get_fill_color=[255, 0, 0, 140],
            get_radius=200,
            radius_scale=6,
        )
    ],
    map_style="mapbox://styles/mapbox/light-v9",
)
st.pydeck_chart(deck)

######################################################################################
# Medal Prediction Page
# if page == "Medal Prediction":
#     st.header("Medal Prediction")

#     # Input country and year for medal prediction
#     country = st.text_input("Enter Country", value="United States")
#     year = st.number_input("Enter Year", min_value=2024, max_value=2100, step=4)

#     if st.button("Predict Medals"):
#         # Use the mock prediction function
#         try:
#             prediction = mock_predict_medals(country, year)
#             st.success(f"In {year}, {country} is predicted to win {prediction['medals']} medals with {prediction['athletes']} athletes.")
#         except Exception as e:
#             st.error(f"Error during prediction: {e}")

######################################################################################
### STEP 2 - Tool calls ###

# @tool
# def queryTable(table_name: str, key: str):
#     """Queries the dynamodb table/tables to retrieve basic information about athletes or medals.
#         Example keys: 
#             'SINKOVIC Valent' for athletes
#             'Croatia' for medals
#         If you need to find medals based on the year look into 'dutmar-medals-2016' table for medals in the 2016 Olympics,
#         'dutmar-medals-2020' for the 2020 Olympics or
#         'dutmar-medals-2024' for the 2024 Olympics.
#         Key for the medals table is 'Country'.
#         If you need info based on the specifiec athlete for specific games query 'dutmar-athletes-2016' for the 2016 Olympics,
#         'dutmar-athletes-2020' for 2020 Olympics or
#         'dutmar-athletes-2024' for 2024 Olympics.
#         Key for the athletes table is 'Name'.
#         Pass the key as surname firstname, 
#     """
#     table = dynamodb.Table(table_name)

#     if "athletes" in table_name.lower():
#         return table.get_item(Key={
#             "name": key
#         })

#     if "medals" in table_name.lower():
#         return table.get_item(Key={
#             "nationality": key
#         })

@tool
def knowledgebase():
       """If other provided tools do not return good value use this tool to search 
            wikipedia to get all the info for specific prompt
       """
       api_wrapper = WikipediaAPIWrapper(top_k_results=5, doc_content_chars_max=100)
       wikipedia = WikipediaQueryRun(api_wrapper=api_wrapper)
       return wikipedia

@tool
def historicalWeatherAPI(lon: str, lat: str, start: str, end: str):
    """Use this to find historical weather data based on the date of each event in the olympics.
        Find the city longitude and latitude and find the exact date for that event.
    """
    response = requests.get("https://archive-api.open-meteo.com/v1/archive", params={
        "latitude": lat,
        "longitude": lon,
        "start_date": start,
        "end_date": end
    })

    return response

@tool
def olympicsNewsAPI(query: str, language: str = "en", sortBy: str = "publishedAt"):
    """Use this to find articles related to the Olympics based on the sports.
       Find the article and find the published date for that article.
    """
    response = requests.get("https://newsapi.org/v2/everything", params={
        "q": query,             # Search query, e.g., 'Olympics'
        "language": language,    # Language filter, defaults to English
        "sortBy": sortBy,        # Sorting, defaults to latest articles
        "apiKey": "c8bc6d70a46a4e5698124a048ae67e0e"  #  NewsAPI key
    })
    return response

@tool
def getInstaFollowers(username: str):
    """Find number of instagram followers for the specific athlete.
        Use knowledgebase tool to find athlete's instagram username
    """
    loader = instaloader.Instaloader()
    profile = instaloader.Profile.from_username(loader.context, username)
    followers = profile.followers
    return followers

# @tool
# def predictMedals(country: str, year: str):
#     """Predicts the total number of medals and athletes for a specific country and a specific year of Olympics.
#         Return total number of medals and total number of athletes.
#     """
#     return predict_future_medals(country, year)



######################################################################################
### STEP 3  - Initialize Chatbot with Agent and Chat History ###
# Define tools available to Agent:

# Define prompt format:

prompt = ChatPromptTemplate.from_messages(
    [("system", """You are a helpful assistant that helps users retrive data about the past summer Olympics games.
        You use visual representation to present charts and diagrams.
        Give summarized and clear responses. Do not include datasources.
        First try to use querying tools and if that fails use knowledgebase tool.
        If you need to predict number of medals use 'predictMedals' tool. Using this tool you will get total number of medals and athletes.
        If you need to search for articles use the 'olympicsNewsAPI' for queries relating to articles
        Use 'getInstaFollowers' tool to find number of followers specific athlete has.
      """),
     ("placeholder", "{history}"), 
     ("human", "{input}"),
     ("placeholder", "{agent_scratchpad}")],
)

tools = []


# Define LLM model and agent
model_id = "anthropic.claude-3-haiku-20240307-v1:0"
agent = create_tool_calling_agent(ChatBedrock(model_id=model_id), tools, prompt)
chain = AgentExecutor(agent=agent, tools=tools, verbose=True)

# Create Chat History Memory
tools = [ knowledgebase, historicalWeatherAPI, olympicsNewsAPI, getInstaFollowers]
model_id = "anthropic.claude-3-haiku-20240307-v1:0"
agent = create_tool_calling_agent(ChatBedrock(model_id=model_id), tools, prompt)
chain = AgentExecutor(agent=agent, tools=tools, verbose=True)

memory = StreamlitChatMessageHistory(key="history")

chain_with_history = RunnableWithMessageHistory(
    chain, lambda _: memory, input_messages_key="input", history_messages_key="history"
)

for message in memory.messages:
    if message.type == "human":
        st.chat_message(message.type, avatar=human_avatar).write(message.content)
    else:
        st.chat_message(message.type, avatar=chatbot_avatar).write(message.content)

if user_input := st.sidebar.chat_input():
    config = {"configurable": {"session_id": "default"}}

    st.sidebar.chat_message("human", avatar=human_avatar).write(user_input)
    response = chain_with_history.invoke({"input": user_input}, config=config)
    st.sidebar.chat_message("ai", avatar=chatbot_avatar).write(response["output"])

if st.sidebar.button("Clear History"):
    memory.clear()
######################################################################################
