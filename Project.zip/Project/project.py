################# Imports

import boto3.dynamodb
import streamlit as st
import boto3
import requests
import pandas as pd
from langchain.tools import tool
from langchain_aws import ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

from langchain.schema import Document
from langchain_community.vectorstores import OpenSearchVectorSearch
from langchain_community.embeddings import BedrockEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

from ml_alg import predict_future_medals
import instaloader
from duckduckgo_search import DDGS
import time
import pandas as pd
import altair as alt
import plotly.graph_objects as go
import feedparser
from urllib.parse import quote
from pytrends.request import TrendReq
import geopandas as gpd
import matplotlib.colors as mcolors
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as plt
import plotly.express as px
import io
import numpy as np

################# Data reading

dynamodb = boto3.resource('dynamodb', region_name="eu-central-1")
s3 = boto3.resource('s3')

human_avatar = "https://cdn-icons-png.flaticon.com/128/1248/1248343.png"
chatbot_avatar = "https://cdn-icons-png.flaticon.com/128/140/140398.png"
olympics_icon = "https://cdn-icons-png.flaticon.com/128/623/623184.png"
gold_medal = 'https://cdn-icons-png.flaticon.com/128/2583/2583344.png'  # Update path to your gold medal image
silver_medal = 'https://cdn-icons-png.flaticon.com/128/2583/2583319.png'  # Update path to your silver medal image
bronze_medal = 'https://cdn-icons-png.flaticon.com/128/2583/2583434.png' # Update path to your bronze medal image

city_data = {
      "City": ["Athens (2004)", "Sydney (2000)", "Beijing (2008)", "London (2012)", "Rio de Janeiro (2016)", "Tokyo (2020)", "Paris (2024)"],
    "latitude": [37.9838, -33.8688, 39.9042, 51.5074, -22.9068, 35.6895, 48.8566],
    "longitude": [23.7275, 151.2093, 116.4074, -0.1278, -43.1729, 139.6917, 2.3522],
    "Year": [
        "2004",  # Athens
        "2000",  # Sydney
        "2008",  # Beijing
        "2012",  # London
        "2016",  # Rio de Janeiro
        "2020",  # Tokyo
        "2024"],  # Paris
    "Mascot_Image": [
        "https://th.bing.com/th/id/OIP.VhoDDcXqfD05i-Rl-1VbBQAAAA?w=184&h=184&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # Athens
        "https://th.bing.com/th/id/OIP.Nc60rYpfJ0S2lF1CBlezlwHaDu?w=340&h=176&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # Sydney
        "https://th.bing.com/th/id/OIP.rG5_bbQl4k0ub6hckVzHQAHaD4?w=297&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # Beijing
        "https://th.bing.com/th/id/OIP.acfj-h5Eb0IdPxQX6yTd0QHaGZ?w=197&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # London
        "https://th.bing.com/th/id/OIP.nhf5cm_cJk3B_q8N6nceUgHaFj?w=231&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # Rio de Janeiro
        "https://th.bing.com/th/id/OIP.2KWgIIVPPaOIs-YwUT4yLAAAAA?w=318&h=175&c=7&r=0&o=5&dpr=1.3&pid=1.7",  # Tokyo
        "https://th.bing.com/th/id/OIP.IUupWwQh7PRBQR9WgNAINQHaFb?w=221&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"],  # Paris
     "Dates": [
        "13.8. - 29.8",  # Athens
        "15.9 - 1.10",  # Sydney
        "8.8. - 24.8",   # Beijing
        "27.7. - 12.8.",  # London
        "5.8. - 21.8.",   # Rio de Janeiro
        "23.7. - 8.8.",   # Tokyo (held in 2021)
        "26.7. - 11.8"   # Paris
    ],
     "Year_Date": [
        "2004-01-01 2004-12-31",  # Athens
        "2000-01-01 2000-12-31",  # Sydney
        "2008-01-01 2008-12-31",   # Beijing
        "2012-01-01 2012-12-31",  # London
        "2016-01-01 2016-12-31",   # Rio de Janeiro
        "2021-01-01 2021-12-31",   # Tokyo (held in 2021)
        "2024-01-01 2024-12-31"   # Paris
    ]
}

df_cities = pd.DataFrame(city_data)
df = pd.read_csv("team_year_total.csv")
df_gdp_pop = pd.read_csv("all_data.csv")

################# Functions 

# Function to make grouped bar chart of won medals for selected countries
def predictMedals(country: str, year: str):
    try:
        medals, athletes = predict_future_medals(country, year, df_gdp_pop)
        st.write(f"In {year}, {country} will take {athletes} athletes to LA and win {medals} medals.")
    
    except ValueError as ve:
        st.error(f"Error: {ve}. Please check the input data.")
    
    except KeyError as ke:
        st.error(f"Missing data for {country} or {year}. Error: {ke}")
    
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")


# Function that makes a grouped bar plot for comparison of number of medals for 2 countries
def compareTotalMedals(country_one: str, country_two:str):
    try:
        filtered_one = df[df['Team'].str.lower() == country_one.lower()]
        filtered_two = df[df['Team'].str.lower() == country_two.lower()]
        
        if filtered_one.empty or filtered_two.empty:
            raise ValueError(f"One or both countries ({country_one}, {country_two}) have no data.")

        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=filtered_one['Year'],
            y=filtered_one['Total_Medals'],
            name=country_one,
            marker_color='indianred'
        ))
        fig.add_trace(go.Bar(
            x=filtered_two['Year'],
            y=filtered_two['Total_Medals'],
            name=country_two,
            marker_color='lightsalmon'
        ))
        fig.update_layout(barmode='group', xaxis_tickangle=-45)

        return fig

    except ValueError as ve:
        st.error(f"Error: {ve}")
    
    except KeyError as ke:
        st.error(f"Missing columns in the dataset. Error: {ke}")
    
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")


# Function to make a line plot for specific country and specific metric
def linePlot(country: str, metrics: str):
    try:
        filtered_data = df[df['Team'].str.lower() == country.lower()]
        
        if filtered_data.empty:
            raise ValueError(f"No data available for {country}.")
        
        filtered_data['Year'] = filtered_data['Year'].astype(int)
        filtered_data['Year'] = filtered_data['Year'].astype('category')

        # Plot based on the selected metric
        if metrics == 'Medals':
            st.line_chart(data=filtered_data, x="Year", y="Total_Medals", x_label="Years", y_label="Number of Medals")
        elif metrics == 'Athletes':
            st.line_chart(data=filtered_data, x="Year", y="Num_Athletes", x_label="Years", y_label="Number of Athletes")
        else:
            raise ValueError(f"Invalid metric: {metrics}. Please select either 'Medals' or 'Athletes'.")

    except ValueError as ve:
        st.error(f"Error: {ve}")
    
    except KeyError as ke:
        st.error(f"Missing column(s) in the dataset. Error: {ke}")
    
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")


# Function to fetch top news for specific olympics
def fetch_top_city_news(city, year):
    try:
        query = f'Olympics {year} {city} news'
        search_results = DDGS().text(query, max_results=5)
        
        articles = []
        for result in search_results:
            title = result.get('title')
            description = result.get('body', 'No description available')
            url = result.get('href', 'No URL available')
            articles.append({'title': title, 'description': description, 'url': url})
        
        return articles
    
    except Exception as e:
        print(f"Error fetching news for {city} in {year}: {e}")
        return [{'title': 'No news available', 'description': 'Unable to retrieve news at the moment.', 'url': ''}]

 
# Function to fetch Google Trends
def fetch_global_trending_searches(timeframe):
    try:
        pytrends = TrendReq(hl='en-US', tz=360)
        keywords = ['Olympics']
        pytrends.build_payload(kw_list=keywords, timeframe=timeframe, geo='')
        trending_data = pytrends.interest_over_time()

        if not trending_data.empty:
            plot_trending_data(trending_data)
        else:
            print("No data available for the given timeframe.")
        
    except Exception as e:
        print(f"Error fetching trending data: {e}")
        return

def plot_trending_data(data):
    # Plot the interest over time
    plt.figure(figsize=(12, 6))
    plt.plot(data.index, data['Olympics'], marker='o', linestyle='-', color='b')
    plt.title("Interest in 'Olympics' Over Time (0-100 Scale)")
    plt.xlabel('Date')
    plt.ylabel('Interest')
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    st.pyplot(plt.gcf())

# Function to display city map
def display_city_map(city_name):
    try:
        city_info = df_cities[df_cities["City"] == city_name]
        if city_info.empty:
            raise ValueError(f"No coordinates found for {city_name}")
        city_coords = city_info[["latitude", "longitude"]]
        st.map(city_coords)
    
    except Exception as e:
        st.error(f"Error displaying map for {city_name}: {e}")

# Function to display Olympic mascots for the selected city
def display_olympic_mascots(city):
    try:
        mascot_img = df_cities[df_cities["City"] == city]["Mascot_Image"].values[0]
        if not mascot_img:
            raise ValueError(f"No mascot image found for {city}")
        st.subheader(f"🎭 Olympic Mascot")
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.image(mascot_img, caption=f"Mascots for {city}", use_column_width=True)
    
    except IndexError:
        st.error(f"No mascot image available for {city}.")
    
    except Exception as e:
        st.error(f"Error displaying mascot for {city}: {e}")

# Function to make a preatty visualization for top 3 countries my the number of medals for specific year
def top_3_countries_by_medals(year: int):
    try:
        top_countries = df[df['Year'] == year]
        
        # Check if data is available for the given year
        if top_countries.empty:
            raise ValueError(f"No data available for the year {year}.")
        
        top_countries = top_countries.sort_values(by='Total_Medals', ascending=False).head(3)
        
        # Check if there are at least 3 countries
        if len(top_countries) < 3:
            raise ValueError(f"Not enough countries with data for the year {year}.")

        # Display medals in markdown with formatted HTML
        st.markdown("""
            <div style="display: flex; justify-content: center; align-items: flex-end; height: 150px;">
                <div style="text-align: center; margin: 0 10px; position: relative; top: 0px;">
                    <img src="{silver_medal}" width="70" />
                    <p style="font-size: 15px;">{team_silver}: {total_medals_silver} Medals</p>
                </div>
                <div style="text-align: center; margin: 0 10px; position: relative; top: -20px;">
                    <img src="{gold_medal}" width="70" />
                    <p style="font-size: 15px;">{team_gold}: {total_medals_gold} Medals</p>
                </div>
                <div style="text-align: center; margin: 0 10px; position: relative; top: 20px;">
                    <img src="{bronze_medal}" width="70" />
                    <p style="font-size: 15px;">{team_bronze}: {total_medals_bronze} Medals</p>
                </div>
            </div>
        """.format(
            gold_medal=gold_medal,
            silver_medal=silver_medal,
            bronze_medal=bronze_medal,
            team_gold=top_countries.iloc[0]['Team'],
            total_medals_gold=top_countries.iloc[0]['Total_Medals'],
            team_silver=top_countries.iloc[1]['Team'],
            total_medals_silver=top_countries.iloc[1]['Total_Medals'],
            team_bronze=top_countries.iloc[2]['Team'],
            total_medals_bronze=top_countries.iloc[2]['Total_Medals']
        ), unsafe_allow_html=True)

    except IndexError:
        st.error("Not enough data to display the top 3 countries.")
    
    except ValueError as ve:
        st.error(f"Error: {ve}")
    
    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")


# Function to display heatmap of medal changes or participants changes:
def plot_changes_interactive(csv_file, shapefile_path, column_to_plot, label):
    """
    Plots an interactive heatmap of countries based on their Olympic changes (medals or participants).
    
    Parameters:
    csv_file (str): Path to the CSV file containing Olympic data with 'country_long' and the selected column.
    shapefile_path (str): Path to the shapefile for world country boundaries.
    column_to_plot (str): The column to plot (either 'medals_change' or 'participants_change').
    label (str): Label for the color bar.
    """

    # Load the CSV data from S3
    s3_bucket = "news-agency"
    s3_key = "processed_data/momentum_change.csv"
    obj = s3.Object(s3_bucket, s3_key)
    csv_data = obj.get()['Body'].read().decode('utf-8')
    
    # Convert CSV data to pandas dataframe
    data = pd.read_csv(io.StringIO(csv_data))
    # Load the CSV data
    #data = pd.read_csv(csv_file)
    
    # Select relevant columns (country_long and the selected column)
    data = data[['country_long', column_to_plot]]
    
    # Extract the top 10 countries with the highest changes for the selected column
    top_10_countries = data.sort_values(by=column_to_plot, ascending=False).head(10)
    
    # Add a "Rank" column and reset the index
    top_10_countries = top_10_countries.reset_index(drop=True)
    top_10_countries['Rank'] = top_10_countries.index + 1
    
    # Rename the columns for better readability
    if column_to_plot == 'medals_change':
        top_10_countries = top_10_countries.rename(columns={'country_long': 'Country', 'medals_change': 'Medals Change'})
        top_10_countries = top_10_countries[['Rank', 'Country', 'Medals Change']]
        top_10_countries['Medals Change'] = top_10_countries['Medals Change'].astype(int)
        top_10_countries = top_10_countries[['Rank', 'Country', 'Medals Change']]  # Drop any index-related columns
    else:
        top_10_countries = top_10_countries.rename(columns={'country_long': 'Country', 'participants_change': 'Participants Change'})
        top_10_countries = top_10_countries[['Rank', 'Country', 'Participants Change']]
        top_10_countries['Participants Change'] = top_10_countries['Participants Change'].astype(int)
    
    # Display the top 10 countries with the highest changes without showing the index
    st.write(f"Top 10 countries with the highest Olympic {label.lower()} (2020 - 2024):")
    st.table(top_10_countries.style.hide(axis='index'))  # Hide the index when displaying the table

    # Load world shapefile
    world = gpd.read_file(shapefile_path)
    
    # Ensure dataset has country names matching the world map (Country names under "ADMIN" in world df)
    world = world[['ADMIN', 'geometry']]
    
    # Merge the world map with changes data on country names
    merged_data = world.merge(data, left_on='ADMIN', right_on='country_long', how='left')
    merged_data = merged_data.rename(columns={'ADMIN': 'Country Name'})
    
    # Convert the merged data to GeoJSON format for Plotly
    merged_data_geojson = merged_data.set_geometry('geometry').__geo_interface__

    # Generate tick values and labels
    min_value = merged_data[column_to_plot].min()
    max_value = merged_data[column_to_plot].max()
    color_range = (min_value, max_value)
    tick_vals = np.linspace(min_value, max_value, num=5)  # 5 ticks for example
    #tick_vals = np.round(tick_vals, 2)  # Round values to 2 decimal places for better readability
    tick_labels = [f"{int(val)}" for val in tick_vals]
    
    # Define a custom diverging color scale where white is at zero
    color_scale = [
        [0.0, "blue"],    # Start of negative range (min value)
        [0.38, "green"],  # End-negative range
        [0.4, "white"],   # Zero change
        [0.42, "orange"], # Start-positive range
        [1.0, "red"],     # End of positive range (max value)
    ]
    
    # Create the interactive map using Plotly
    fig = px.choropleth(
        merged_data,
        geojson=merged_data_geojson,
        locations='Country Name',  # The column in the data to match with GeoJSON features
        featureidkey="properties.Country Name",  # The GeoJSON feature property for country names
        color=column_to_plot,
        hover_name='Country Name',  # Display country name on hover
        hover_data={column_to_plot: True},  # Show selected change data on hover
        color_continuous_scale=color_scale,  # Custom diverging color scale
        range_color=color_range,  # Dynamic color range
        labels={column_to_plot: label},  # Label for the legend
        projection='natural earth'  # Projection type
    )
    
    # Update the layout and appearance of the map
    fig.update_geos(
        showcountries=True, countrycolor="black",  # Show country borders
        showcoastlines=True, coastlinecolor="black",
        showland=True, landcolor="lightgray",
        fitbounds="locations"  # Fit the map to the dataset bounds
    )
    
    # Customize the color bar
    fig.update_layout(
        title_text=f"Olympic {label} by Country (2020 - 2024)",
        margin={"r":0,"t":40,"l":0,"b":0},  # Set margins
        coloraxis_colorbar={
            'title': label,
            'tickvals': tick_vals.tolist(),  # Convert numpy array to list
            'ticktext': tick_labels  # Dynamic tick text
        }
    )
    
    # Display the Plotly figure in Streamlit
    st.plotly_chart(fig)

################### Main page layout
st.set_page_config(page_title="Alpha News", page_icon=olympics_icon)
st.markdown("<h1 style='text-align: center;'>🏃🏋🏿 Alpha News 🤾🏾🤺</h1>" , unsafe_allow_html=True)
#st.title("Alpha News")

st.subheader("🏟 Visualization Options")
 
# Checkboxes for different visualizations
col1, col2 = st.columns(2)

with col1:
    show_line_plot = st.checkbox("📊 Line plot: Medals per Country")
    show_bar_chart = st.checkbox("📊 Compare countries success")

with col2:
    show_momentum = st.checkbox("💡 Momentum Insights")
    make_predictions = st.checkbox("🧙 Make predictions")

if show_bar_chart:
    col1, col2 = st.columns(2)
    with col1:
        country_one = st.text_input(label="Country one")
    with col2:
        country_two = st.text_input(label="Country two")
    
    fig = compareTotalMedals(country_one, country_two)

    if st.button("Compare"):
        fig = compareTotalMedals(country_one, country_two)
        st.plotly_chart(fig)

if show_line_plot:
    col1, col2 = st.columns(2)
    with col1:
        country = st.text_input(label="Country")
    with col2:
        metrics = st.selectbox(
            'Select an option to display:',
            ['Medals', 'Athletes']
        )

    if st.button("Plot"):
        linePlot(country, metrics)

# Path definitions for heatmap:
shapefile_path = "countries_shapefile/ne_110m_admin_0_countries.shp"
momentum_csv_file_path = "momentum_change.csv"

if show_momentum:
    # Add a selection box to choose between 'Medal Changes' and 'Participants Changes'
    change_type = st.selectbox(
        "Select the type of momentum metric to display:",
        ("Medal Changes", "Participants Changes")
    )
    
    # Determine which column to plot based on the selection
    if change_type == "Medal Changes":
        column_to_plot = 'medals_change'
        label = 'Medal Changes'
    else:
        column_to_plot = 'participants_change'
        label = 'Participants Changes'
    
    # Plot the interactive heatmap based on the selected data
    plot_changes_interactive(momentum_csv_file_path, shapefile_path, column_to_plot, label)

if make_predictions:
    st.title("Predict results for LA (2028)")
    country_to_predict = st.text_input(label="Country to predict")
    
    if st.button("Predict"):
        predictMedals(country_to_predict, "2028")


# Dropdown for olympics selection
st.title("Olympics City Selector") 
city = st.selectbox("Choose an Olympic City", df_cities["City"].unique())
 
# Redirect to another page for city-specific details
if city:
    city_info = df_cities[df_cities["City"] == city]
    year = city_info["Year"]
    year = int(year)
    date = str(city_info["Dates"].iloc[0])
    year_date = str(city_info["Year_Date"].iloc[0])

    st.markdown(f"### **Details for {city}**")
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader(f"📅 Dates")
        dates = df_cities[df_cities["City"] == city]["Dates"].iloc[0]
        st.markdown(f"""
            <div style="font-size: 25px; color: #4a90e2;">
                {dates}
            </div>
        """, unsafe_allow_html=True)
        #st.write(f"{dates}")
    with col2:
        # Display mascots for the selected Olympic city
        display_olympic_mascots(city)
 
    # Display medalists
    st.subheader(f"🏆 Top 3 Countries by Medals")
    top_3_countries_by_medals(year)   

    # Display news
    st.subheader(f"📰 Top News during {year} Olympics")
    top_article = fetch_top_city_news(city, year)
    if top_article:
        for article in top_article:
            st.write(f"**[{article['title']}]({article['url']})**")
            st.write(article['description'])  # Display the description of the top article
    
    else:
        st.write("No news articles available at the moment.")

    st.subheader(f"🔍 Popularity of Olympic-Related Searches")
    fetch_global_trending_searches(year_date)

    st.subheader(f"📍 Map of {city}")
    display_city_map(city) 

prompt = ChatPromptTemplate.from_messages(
    [("system", """You are a helpful assistant that helps users retrive data about the past summer Olympics games.
        You use visual representation to present charts and diagrams.
        Give summarized and clear responses. Do not include datasources.
        First try to use querying tools and if that fails use knowledgebase tool.
        Querying can be done by column_name 'Team' which represent name of the country or 'Name' as first and last name of athlete.
        If you need to predict number of medals use 'predictMedals' tool. Using this tool you will get total number of medals and athletes.
      You shouldn't predict the number of medals for 2024., this you already have in table.
        Use 'getInstaFollowers' tool to find number of followers specific athlete has.
      """),
     ("placeholder", "{history}"), 
     ("human", "{input}"),
     ("placeholder", "{agent_scratchpad}")],
)

@tool
def queryTable(table_name: str, name: str, column_name: str):
    """Queries the dynamodb table/tables to retrieve basic information about athletes or medals.
        Query the 'news-olympic-table' table and use first name last name as a name. Query in this case by column 'Name'.
        Example: 'Moonika Aava'.
        Also quering by country can be done. In this case you should searc by column 'Team'.
    """
    table = dynamodb.Table(table_name)
    response = table.scan(
            FilterExpression=boto3.dynamodb.conditions.Attr(column_name).eq(name)
        )
    
    return response.get('Items', [])
    
@tool
def knowledgebase():
       """If other provided tools do not return good value use this tool to search 
            wikipedia to get all the info for specific prompt
       """
       api_wrapper = WikipediaAPIWrapper(top_k_results=5, doc_content_chars_max=100)
       wikipedia = WikipediaQueryRun(api_wrapper=api_wrapper)
       return wikipedia

@tool
def historicalWeatherAPI(lon: str, lat: str, start: str, end: str):
    """Use this to find historical weather data based on the date of each event in the olympics.
        Find the city longitude and latitude and find the exact date for that event.
    """
    response = requests.get("https://archive-api.open-meteo.com/v1/archive", params={
        "latitude": lat,
        "longitude": lon,
        "start_date": start,
        "end_date": end
    })

    return response

@tool
def predictMedals(country: str, year: str):
    """Predicts the total number of medals and athletes for a specific country and a specific year of Olympics.
        Return total number of medals and total number of athletes.
    """
    return predict_future_medals(country, year, df_gdp_pop)

@tool
def getInstaFollowers(username: str):
    """Find number of instagram followers for the specific athlete.
        Use knowledgebase tool to find athlete's instagram username
    """
    loader = instaloader.Instaloader()
    profile = instaloader.Profile.from_username(loader.context, username)
    followers = profile.followers
    return followers

@tool
def fetchOlympicsNews(country, year, max_results=5):
    """Fetching top max_results articles
       Return every title in new line in form of bullet points.
    """
    query = f'Olympics {year} news in {country}'
    search_results = DDGS().text(query, max_results=max_results)

    urls = []
    titles = []
    
    for result in search_results:
        url = result['href']
        title = result['title']  # Directly get the title from the search result
        
        urls.append(url)
        titles.append(title)
        
        time.sleep(2)  # Adding delay to avoid being blocked by the server
    
    df = pd.DataFrame({"country": country, "year": year, "url": urls, "title": titles})
    return df["title"]

@tool
def sentimentClassifierNewsArticle(city:str, year:str):
    """
        Use the city name and year mentioned in user's query to fetch the relevant articles.
        Classify the sentiment for each article based on the descriptions. 
        Return "Positive", "Negative" or "Neutral". Summarise the reason for the sentiment in one or two sentences.
        List it in bullet forms.      
    """
    news_articles = fetch_top_city_news(city, year)
    return news_articles

tools = [queryTable, knowledgebase, historicalWeatherAPI, predictMedals, getInstaFollowers, fetchOlympicsNews, sentimentClassifierNewsArticle]
model_id = "anthropic.claude-3-haiku-20240307-v1:0"
agent = create_tool_calling_agent(ChatBedrock(model_id=model_id, region_name="eu-central-1"), tools, prompt)
chain = AgentExecutor(agent=agent, tools=tools, verbose=True)

memory = StreamlitChatMessageHistory(key="history")

chain_with_history = RunnableWithMessageHistory(
    chain, lambda _: memory, input_messages_key="input", history_messages_key="history"
)

st.markdown(
    """
    <style>
    /* Adjust the sidebar width */
    [data-testid="stSidebar"] {
        width: 300px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.image(olympics_icon)
    st.title("News Chatbot")
    try:
        if user_input := st.chat_input(placeholder="Ask me questions about the Olympics"):
            config = {"configurable": {"session_id": "default"}}

            st.chat_message("human", avatar=human_avatar).write(user_input)
            response = chain_with_history.invoke({"input": user_input}, config=config)
            st.chat_message("ai", avatar=chatbot_avatar).write(response["output"])

        # Disable "Clear History" button if memory is empty
        if 'memory' not in st.session_state:
            st.session_state['memory'] = []

        # Disable "Clear History" if memory is empty
        if st.button("Clear History", disabled=len(st.session_state['memory']) == 0):
            st.session_state['memory'].clear()
    except Exception as e:
        st.error("Chatbot not available at the moment. Please try again later.")
        # Optionally log the exception to troubleshoot
        print(f"Error: {e}")
